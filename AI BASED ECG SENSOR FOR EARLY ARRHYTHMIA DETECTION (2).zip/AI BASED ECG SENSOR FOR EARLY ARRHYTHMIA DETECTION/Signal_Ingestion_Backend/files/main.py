from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.responses import HTMLResponse
import numpy as np
import io
import csv
from datetime import datetime
from scipy.signal import butter, filtfilt, iirnotch, find_peaks

app = FastAPI(title="CardioSense AI — CSV Analyzer", version="1.0")

SAMPLE_RATE = 250   # Hz — change this if your CSV uses a different rate
#  PREPROCESSING FUNCTIONS
def bandpass_filter(signal, lowcut=0.5, highcut=40.0, fs=250):
    nyquist = fs / 2
    low     = lowcut  / nyquist
    high    = highcut / nyquist
    b, a    = butter(N=4, Wn=[low, high], btype='band')
    return filtfilt(b, a, signal)

def notch_filter(signal, freq=50.0, Q=30.0, fs=250):
    b, a = iirnotch(w0=freq, Q=Q, fs=fs)
    return filtfilt(b, a, signal)

def normalize(signal):
    mn, mx = np.min(signal), np.max(signal)
    if mx - mn == 0:
        return signal
    return (signal - mn) / (mx - mn)

def detect_r_peaks(signal, fs=250):
    diff      = np.diff(signal)
    squared   = diff ** 2
    win       = int(0.150 * fs)
    kernel    = np.ones(win) / win
    smoothed  = np.convolve(squared, kernel, mode='same')
    peaks, _  = find_peaks(
        smoothed,
        distance=int(0.2 * fs),
        height=0.3 * np.max(smoothed)
    )
    return peaks

def segment_beats(signal, r_peaks, fs=250, window_ms=360):
    half  = int((window_ms / 1000) * fs)
    beats = []
    for peak in r_peaks:
        start = peak - half
        end   = peak + half
        if start < 0 or end > len(signal):
            continue
        beats.append(signal[start:end].tolist())
    return beats

def extract_hrv(r_peaks, fs=250):
    if len(r_peaks) < 2:
        return {}
    rr_ms   = np.diff(r_peaks) / fs * 1000
    sdiffs  = np.diff(rr_ms)
    nn50    = np.sum(np.abs(sdiffs) > 50)
    return {
        "mean_rr_ms"  : round(float(np.mean(rr_ms)), 2),
        "mean_hr_bpm" : round(float(60000 / np.mean(rr_ms)), 2),
        "min_hr_bpm"  : round(float(60000 / np.max(rr_ms)), 2),
        "max_hr_bpm"  : round(float(60000 / np.min(rr_ms)), 2),
        "sdnn_ms"     : round(float(np.std(rr_ms)), 2),
        "rmssd_ms"    : round(float(np.sqrt(np.mean(sdiffs ** 2))), 2),
        "pnn50_pct"   : round(float((nn50 / len(sdiffs)) * 100), 2),
    }

def classify_simple(hrv, beats_count):
    """
    Rule-based classifier — placeholder until your ML model is ready.
    Returns a risk assessment based on HRV values.
    """
    if not hrv:
        return "Unknown", "LOW", "Not enough data for analysis"

    hr   = hrv.get("mean_hr_bpm", 70)
    sdnn = hrv.get("sdnn_ms", 50)

    if hr > 150:
        return "Ventricular Tachycardia (suspected)", "HIGH", "Heart rate critically high"
    if hr < 40:
        return "Bradycardia (suspected)", "HIGH", "Heart rate critically low"
    if hr > 100 and sdnn < 20:
        return "Atrial Fibrillation (suspected)", "MEDIUM", "Elevated HR with low HRV"
    if sdnn < 20:
        return "Low HRV — monitoring needed", "MEDIUM", "Reduced heart rate variability"
    if 60 <= hr <= 100 and sdnn >= 30:
        return "Normal Sinus Rhythm", "LOW", "All metrics within normal range"
    return "Inconclusive — further review needed", "MEDIUM", "Borderline metrics detected"
#  CSV PARSER — handles multiple formats automatically
def parse_csv(content: bytes):
    """
    Accepts CSV files in any of these formats:
      1. Single column:       512.3
      2. Two columns:         0.001, 512.3    (time, value)
      3. With header row:     time,ecg  /  sample,value  /  ecg  etc.
    Returns: (samples list, column_name, detected_format)
    """
    text    = content.decode("utf-8", errors="ignore")
    reader  = csv.reader(io.StringIO(text))
    rows    = list(reader)

    if not rows:
        raise HTTPException(status_code=400, detail="CSV file is empty")

    # Detect header
    start_row   = 0
    col_index   = 0
    col_name    = "ecg"
    fmt         = "single column"

    first = rows[0]
    # Check if first row is a header (non-numeric)
    try:
        float(first[0].strip())
    except ValueError:
        start_row = 1
        col_name  = first[-1].strip()   # last column name = ECG signal

    # Detect number of columns
    if len(rows[start_row]) >= 2:
        fmt       = "two columns (time, value)"
        col_index = 1    # second column = ECG value
    else:
        fmt       = "single column (value only)"
        col_index = 0

    samples = []
    for row in rows[start_row:]:
        if not row:
            continue
        try:
            val = float(row[col_index].strip())
            samples.append(val)
        except (ValueError, IndexError):
            continue

    if len(samples) < 100:
        raise HTTPException(
            status_code=400,
            detail=f"Too few valid samples ({len(samples)}). Need at least 100."
        )

    return samples, col_name, fmt

# ================================================================
#  ROUTES

@app.get("/", response_class=HTMLResponse)
def home():
    return """
<!DOCTYPE html>
<html>
<head>
  <title>CardioSense AI</title>
  <style>
    * { margin:0; padding:0; box-sizing:border-box; }
    body {
      background:#050d1a; color:#e0eaf5;
      font-family:'Courier New', monospace;
      display:flex; align-items:center;
      justify-content:center; min-height:100vh;
    }
    .card {
      background:#0b1520; border:1px solid #1a3045;
      border-radius:12px; padding:40px; width:480px;
    }
    h1 { color:#00d4ff; font-size:20px; margin-bottom:6px; letter-spacing:2px; }
    p  { color:#6b8ba4; font-size:13px; margin-bottom:28px; }

    .upload-area {
      border:2px dashed #1a3045; border-radius:8px;
      padding:32px; text-align:center; cursor:pointer;
      transition:border-color 0.2s; margin-bottom:20px;
    }
    .upload-area:hover { border-color:#00d4ff; }
    .upload-area input { display:none; }
    .upload-icon { font-size:32px; margin-bottom:10px; }
    .upload-text { color:#6b8ba4; font-size:13px; }
    .file-name   { color:#00d4ff; font-size:13px; margin-top:8px; display:none; }

    .sample-rate-row {
      display:flex; align-items:center; gap:12px;
      margin-bottom:20px;
    }
    .sample-rate-row label { color:#6b8ba4; font-size:13px; flex:1; }
    .sample-rate-row input {
      background:#050d1a; border:1px solid #1a3045;
      color:#e0eaf5; padding:8px 12px; border-radius:6px;
      font-family:'Courier New', monospace; font-size:13px; width:90px;
    }

    button {
      width:100%; padding:14px;
      background:#00d4ff; color:#050d1a;
      border:none; border-radius:8px;
      font-size:15px; font-weight:bold;
      cursor:pointer; font-family:'Courier New', monospace;
      letter-spacing:1px;
    }
    button:disabled { background:#1a3045; color:#6b8ba4; cursor:not-allowed; }
    button:hover:not(:disabled) { background:#00b8db; }

    #result { margin-top:24px; display:none; }

    .metric-grid {
      display:grid; grid-template-columns:1fr 1fr;
      gap:10px; margin-bottom:16px;
    }
    .metric {
      background:#050d1a; border:1px solid #1a3045;
      border-radius:8px; padding:12px; text-align:center;
    }
    .metric-label { font-size:10px; color:#6b8ba4; margin-bottom:4px; }
    .metric-value { font-size:22px; color:#00d4ff; font-weight:bold; }
    .metric-unit  { font-size:10px; color:#6b8ba4; }

    .diagnosis {
      border-radius:8px; padding:16px; margin-bottom:16px;
      text-align:center;
    }
    .diagnosis.LOW    { background:rgba(0,255,159,0.08); border:1px solid rgba(0,255,159,0.3); }
    .diagnosis.MEDIUM { background:rgba(255,179,71,0.08); border:1px solid rgba(255,179,71,0.3); }
    .diagnosis.HIGH   { background:rgba(255,77,109,0.12); border:1px solid rgba(255,77,109,0.4); animation:pulse 1.2s infinite; }

    .diag-label { font-size:10px; color:#6b8ba4; margin-bottom:6px; }
    .diag-name  { font-size:16px; font-weight:bold; }
    .diag-name.LOW    { color:#00ff9f; }
    .diag-name.MEDIUM { color:#ffb347; }
    .diag-name.HIGH   { color:#ff4d6d; }
    .diag-reason { font-size:12px; color:#6b8ba4; margin-top:4px; }

    .risk-badge {
      display:inline-block; padding:3px 12px;
      border-radius:12px; font-size:11px; font-weight:bold;
      margin-top:6px;
    }
    .risk-badge.LOW    { background:rgba(0,255,159,0.15); color:#00ff9f; }
    .risk-badge.MEDIUM { background:rgba(255,179,71,0.15); color:#ffb347; }
    .risk-badge.HIGH   { background:rgba(255,77,109,0.2);  color:#ff4d6d; }

    .info-row {
      display:flex; justify-content:space-between;
      font-size:12px; color:#6b8ba4;
      padding:6px 0; border-bottom:1px solid #1a3045;
    }
    .info-row span:last-child { color:#e0eaf5; }

    #loading {
      text-align:center; padding:20px;
      color:#00d4ff; display:none; font-size:13px;
    }
    .spinner {
      width:24px; height:24px; border:2px solid #1a3045;
      border-top-color:#00d4ff; border-radius:50%;
      animation:spin 0.8s linear infinite;
      margin:0 auto 10px;
    }
    @keyframes spin  { to { transform:rotate(360deg); } }
    @keyframes pulse { 0%,100%{opacity:1} 50%{opacity:0.6} }

    .error-box {
      background:rgba(255,77,109,0.1); border:1px solid rgba(255,77,109,0.3);
      border-radius:8px; padding:14px; color:#ff4d6d;
      font-size:13px; margin-top:16px; display:none;
    }

    .csv-hint {
      background:#0b1520; border:1px solid #1a3045;
      border-radius:8px; padding:14px; margin-top:16px;
    }
    .csv-hint-title { font-size:11px; color:#6b8ba4; margin-bottom:8px; }
    .csv-hint pre {
      font-size:11px; color:#00ff9f; line-height:1.6;
      white-space:pre-wrap;
    }
  </style>
</head>
<body>
<div class="card">
  <h1>&#10084; CARDIOSENSE AI</h1>
  <p>Upload a CSV file to analyze ECG signal</p>

  <div class="upload-area" onclick="document.getElementById('fileInput').click()">
    <input type="file" id="fileInput" accept=".csv" onchange="onFileChange(event)" />
    <div class="upload-icon">&#128190;</div>
    <div class="upload-text">Click to choose CSV file</div>
    <div class="file-name" id="fileName"></div>
  </div>

  <div class="sample-rate-row">
    <label>Sample Rate (Hz) — default 250</label>
    <input type="number" id="sampleRate" value="250" min="1" max="5000" />
  </div>

  <button id="analyzeBtn" onclick="analyzeCSV()" disabled>
    ANALYZE ECG
  </button>

  <div id="loading">
    <div class="spinner"></div>
    Analyzing ECG signal...
  </div>

  <div class="error-box" id="errorBox"></div>

  <div id="result"></div>

  <div class="csv-hint">
    <div class="csv-hint-title">Accepted CSV formats:</div>
    <pre>Format 1 — single column:
512.3
514.1
509.8

Format 2 — two columns (time, ecg):
0.000, 512.3
0.004, 514.1

Format 3 — with header:
time,ecg
0.000,512.3
0.004,514.1</pre>
  </div>
</div>

<script>
  let selectedFile = null;

  function onFileChange(e) {
    selectedFile = e.target.files[0];
    const fn = document.getElementById("fileName");
    fn.textContent = selectedFile ? selectedFile.name : "";
    fn.style.display = selectedFile ? "block" : "none";
    document.getElementById("analyzeBtn").disabled = !selectedFile;
    document.getElementById("errorBox").style.display = "none";
    document.getElementById("result").style.display   = "none";
  }

  async function analyzeCSV() {
    if (!selectedFile) return;

    const sr   = document.getElementById("sampleRate").value;
    const form = new FormData();
    form.append("file", selectedFile);

    document.getElementById("loading").style.display   = "block";
    document.getElementById("result").style.display    = "none";
    document.getElementById("errorBox").style.display  = "none";
    document.getElementById("analyzeBtn").disabled     = true;

    try {
      const res  = await fetch(`/analyze?sample_rate=${sr}`, { method:"POST", body:form });
      const data = await res.json();

      document.getElementById("loading").style.display = "none";
      document.getElementById("analyzeBtn").disabled   = false;

      if (!res.ok) {
        const eb = document.getElementById("errorBox");
        eb.textContent    = "Error: " + (data.detail || "Something went wrong");
        eb.style.display  = "block";
        return;
      }

      renderResult(data);
    } catch(err) {
      document.getElementById("loading").style.display = "none";
      document.getElementById("analyzeBtn").disabled   = false;
      const eb = document.getElementById("errorBox");
      eb.textContent   = "Network error: " + err.message;
      eb.style.display = "block";
    }
  }

  function renderResult(d) {
    const hrv  = d.hrv_features;
    const risk = d.risk_level;

    document.getElementById("result").innerHTML = `
      <div class="diagnosis ${risk}">
        <div class="diag-label">CLASSIFICATION RESULT</div>
        <div class="diag-name ${risk}">${d.classification}</div>
        <div class="diag-reason">${d.reason}</div>
        <div><span class="risk-badge ${risk}">${risk} RISK</span></div>
      </div>

      <div class="metric-grid">
        <div class="metric">
          <div class="metric-label">HEART RATE</div>
          <div class="metric-value">${hrv.mean_hr_bpm ?? "--"}</div>
          <div class="metric-unit">BPM</div>
        </div>
        <div class="metric">
          <div class="metric-label">BEATS FOUND</div>
          <div class="metric-value">${d.beats_found}</div>
          <div class="metric-unit">beats</div>
        </div>
        <div class="metric">
          <div class="metric-label">SDNN</div>
          <div class="metric-value">${hrv.sdnn_ms ?? "--"}</div>
          <div class="metric-unit">ms</div>
        </div>
        <div class="metric">
          <div class="metric-label">RMSSD</div>
          <div class="metric-value">${hrv.rmssd_ms ?? "--"}</div>
          <div class="metric-unit">ms</div>
        </div>
      </div>

      <div class="info-row"><span>File</span><span>${d.file_info.filename}</span></div>
      <div class="info-row"><span>Total samples</span><span>${d.file_info.total_samples}</span></div>
      <div class="info-row"><span>Duration</span><span>${d.file_info.duration_sec} sec</span></div>
      <div class="info-row"><span>Sample rate</span><span>${d.file_info.sample_rate} Hz</span></div>
      <div class="info-row"><span>CSV format</span><span>${d.file_info.detected_format}</span></div>
      <div class="info-row"><span>Mean RR interval</span><span>${hrv.mean_rr_ms ?? "--"} ms</span></div>
      <div class="info-row"><span>Min HR</span><span>${hrv.min_hr_bpm ?? "--"} BPM</span></div>
      <div class="info-row"><span>Max HR</span><span>${hrv.max_hr_bpm ?? "--"} BPM</span></div>
      <div class="info-row"><span>pNN50</span><span>${hrv.pnn50_pct ?? "--"} %</span></div>
      <div class="info-row"><span>Analyzed at</span><span>${d.analyzed_at}</span></div>
    `;
    document.getElementById("result").style.display = "block";
  }
</script>
</body>
</html>
"""

@app.post("/analyze")
async def analyze_csv(file: UploadFile = File(...), sample_rate: int = 250):
    # ── Validate file type ────────────────────────────────────────
    if not file.filename.endswith(".csv"):
        raise HTTPException(status_code=400, detail="Only .csv files are accepted")

    content = await file.read()
    if len(content) == 0:
        raise HTTPException(status_code=400, detail="Uploaded file is empty")

    # ── Parse CSV ────────────────────────────────────────────────
    samples, col_name, detected_format = parse_csv(content)
    signal = np.array(samples)

    # ── Preprocess ───────────────────────────────────────────────
    try:
        signal = bandpass_filter(signal, fs=sample_rate)
        signal = notch_filter(signal, fs=sample_rate)
        signal = normalize(signal)
    except Exception as e:
        raise HTTPException(status_code=422, detail=f"Preprocessing failed: {str(e)}")

    # ── Detect R-peaks ───────────────────────────────────────────
    r_peaks = detect_r_peaks(signal, fs=sample_rate)
    beats   = segment_beats(signal, r_peaks, fs=sample_rate)

    # HRV Features 
    hrv = extract_hrv(r_peaks, fs=sample_rate)

    #  Classify
    classification, risk_level, reason = classify_simple(hrv, len(beats))

    return {
        "status"        : "analyzed",
        "analyzed_at"   : datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC"),
        "file_info"     : {
            "filename"       : file.filename,
            "total_samples"  : len(samples),
            "duration_sec"   : round(len(samples) / sample_rate, 2),
            "sample_rate"    : sample_rate,
            "detected_format": detected_format,
            "column_used"    : col_name,
        },
        "beats_found"   : len(beats),
        "r_peaks_count" : len(r_peaks),
        "hrv_features"  : hrv,
        "classification": classification,
        "risk_level"    : risk_level,
        "reason"        : reason,
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="127.0.0.1", port=8000, reload=True)
