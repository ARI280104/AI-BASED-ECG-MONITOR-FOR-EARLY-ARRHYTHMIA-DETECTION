#  Run: python -m uvicorn main:app --reload
from fastapi import FastAPI
from fastapi.responses import HTMLResponse
from pydantic import BaseModel
from typing import List
from datetime import datetime
from collections import defaultdict
import numpy as np
app = FastAPI(title="CardioSense AI", version="1.0")
# Config 
SAMPLE_RATE  = 250          # Hz (ESP32 sends 250 samples/second)
WINDOW_SIZE  = SAMPLE_RATE * 10    # 2500 samples = 10 seconds
STEP_SIZE    = SAMPLE_RATE * 5     # slide by 5 seconds (50% overlap)
# In-memory buffer per device (key = device_id)
buffers: dict = defaultdict(list)
windows_ready: dict = defaultdict(list)   # store completed windows
# Data Models 
class ECGBatch(BaseModel):
    """For /upload — send all 10 seconds at once"""
    device_id   : str
    patient_id  : str
    samples     : List[float]    # list of ADC readings e.g. [512.0, 515.3, ...]
    sample_rate : int = 250
class ECGSample(BaseModel):
    """For /stream — send one sample at a time"""
    device_id  : str
    patient_id : str
    value      : float           # single ADC reading
# Helper 
def attach_timestamps(samples: List[float], sample_rate: int) -> List[dict]:
    """Attach a timestamp to every sample based on sample index"""
    now = datetime.utcnow()
    result = []
    for i, val in enumerate(samples):
        offset_ms = (i / sample_rate) * 1000
        result.append({
            "index"     : i,
            "value"     : val,
            "offset_ms" : round(offset_ms, 2)
        })
    return result
def process_window(window: List[dict], device_id: str, patient_id: str) -> dict:
    """
    Placeholder for the full preprocessing + ML pipeline.
    In your real code, call:
      preprocess_ecg() → extract_all_features() → classify_ecg()
    """
    values = [s["value"] for s in window]
    return {
        "device_id"    : device_id,
        "patient_id"   : patient_id,
        "received_at"  : datetime.utcnow().isoformat(),
        "num_samples"  : len(values),
        "duration_sec" : round(len(values) / SAMPLE_RATE, 1),
        "mean_value"   : round(float(np.mean(values)), 3),
        "min_value"    : round(float(np.min(values)), 3),
        "max_value"    : round(float(np.max(values)), 3),
        "status"       : "ready_for_preprocessing"
        # TODO: add preprocess + classify output here
    }
#  Routes 
@app.get("/", response_class=HTMLResponse)
def home():
    return """
    <html><body style="font-family:monospace; background:#050d1a; color:#00d4ff; padding:40px">
    <h2>CardioSense AI — Running</h2>
    <p>Endpoints:</p>
    <ul>
      <li><b>POST /upload</b>  — Send full 10-second batch</li>
      <li><b>POST /stream</b>  — Send one sample at a time</li>
      <li><b>GET  /status</b>  — Check buffer status</li>
      <li><b>GET  /windows/{device_id}</b> — Get ready windows</li>
      <li><b>GET  /docs</b>    — Interactive API docs</li>
      <li><b>POST /simulate</b> — Test with fake data (no ESP32 needed)</li>
    </ul>
    </body></html>
    """
@app.post("/upload")
def upload_ecg(payload: ECGBatch):
    """
    ESP32 collects 10 seconds of data, sends it all at once.
    Simpler approach — good for beginners.
    """
    if len(payload.samples) == 0:
        return {"error": "No samples received"}
    # Attach timestamps
    timestamped = attach_timestamps(payload.samples, payload.sample_rate)
    # Process immediately (single window)
    result = process_window(timestamped, payload.device_id, payload.patient_id)
    return {
        "status"  : "received",
        "message" : f"Got {len(payload.samples)} samples ({len(payload.samples)/payload.sample_rate:.1f} sec)",
        "result"  : result
    }
@app.post("/stream")
def stream_ecg(sample: ECGSample):
    """
    ESP32 sends one reading at a time continuously.
    Server buffers them and processes every 10-second window.
    Uses sliding window (50% overlap).
    """
    device = sample.device_id
    # Add to buffer with timestamp
    buffers[device].append({
        "index"    : len(buffers[device]),
        "value"    : sample.value,
        "timestamp": datetime.utcnow().isoformat()
    })
    current_size = len(buffers[device])
    # Check if we have a full window
    if current_size >= WINDOW_SIZE:
        window = buffers[device][:WINDOW_SIZE]
        # Slide: remove only STEP_SIZE samples (not the full window)
        buffers[device] = buffers[device][STEP_SIZE:]
        # Process window
        result = process_window(window, sample.device_id, sample.patient_id)
        windows_ready[device].append(result)
        return {
            "status"         : "window_ready",
            "samples_in_window": len(window),
            "windows_captured" : len(windows_ready[device]),
            "buffer_remaining" : len(buffers[device]),
            "result"           : result
        }
    return {
        "status"  : "buffering",
        "collected": current_size,
        "needed"   : WINDOW_SIZE,
        "progress" : f"{round((current_size/WINDOW_SIZE)*100, 1)}%"
    }
@app.get("/status")
def get_status():
    """Check how much data is buffered per device"""
    return {
        "active_devices": list(buffers.keys()),
        "buffer_sizes"  : {k: len(v) for k, v in buffers.items()},
        "windows_ready" : {k: len(v) for k, v in windows_ready.items()},
        "window_size"   : WINDOW_SIZE,
        "sample_rate"   : SAMPLE_RATE
    }
@app.get("/windows/{device_id}")
def get_windows(device_id: str):
    """Retrieve all processed windows for a device"""
    if device_id not in windows_ready:
        return {"error": f"No data for device '{device_id}'"}
    return {
        "device_id"    : device_id,
        "total_windows": len(windows_ready[device_id]),
        "windows"      : windows_ready[device_id]
    }
@app.post("/simulate")
def simulate_esp32(seconds: int = 10):
    """
    Simulates ESP32 sending data — test without real hardware.
    Generates fake ECG-like samples and pushes through /upload.
    """
    if seconds < 1 or seconds > 60:
        return {"error": "seconds must be between 1 and 60"}
    num_samples = SAMPLE_RATE * seconds
    t = np.linspace(0, seconds, num_samples)
    # Fake ECG: sine wave + harmonics + small noise
    fake_ecg = (
        0.5 * np.sin(2 * np.pi * 1.2 * t)       # base heart rhythm (~72 BPM)
      + 0.2 * np.sin(2 * np.pi * 2.4 * t)        # 2nd harmonic
      + 0.05 * np.random.randn(num_samples)       # noise
    )
    # Scale to ADC range 0–1023 (like ESP32)
    fake_ecg = ((fake_ecg + 1) / 2) * 1023
    samples = fake_ecg.tolist()
    timestamped = attach_timestamps(samples, SAMPLE_RATE)
    result = process_window(timestamped, "esp32-sim", "patient-test")
    return {
        "status"     : "simulation_complete",
        "message"    : f"Simulated {seconds} seconds of ECG ({num_samples} samples)",
        "sample_preview": samples[:10],   # first 10 values
        "result"     : result
    }
# Run directly (alternative to uvicorn command)
if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="127.0.0.1", port=8000, reload=True)
